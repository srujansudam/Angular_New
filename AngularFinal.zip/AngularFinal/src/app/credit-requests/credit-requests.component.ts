import { Component, OnInit } from '@angular/core';
import { CreditCard } from '../model/creditcard';
import { BankerService } from '../service/banker.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Banker } from '../model/banker';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-credit-requests',
  templateUrl: './credit-requests.component.html',
  styleUrls: ['./credit-requests.component.css']
})
export class CreditRequestsComponent implements OnInit {

  cards: CreditCard[];
  banker: Banker;

  constructor(private bankerService: BankerService,
    private actRt: ActivatedRoute,
    private router: Router,
    private loginService: LoginService) {

    this.banker = this.loginService.banker;
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.bankerService.cardRequestsForMe(this.banker.bankerId).subscribe(
      (data) => {
        this.cards = data;
      }
    );
  }

  approve(cardNumber: number) {
    if (confirm("Press ok to confirm your decision as approve")) {
      this.bankerService.approveOrDisapproveCards(cardNumber, 'Approve').subscribe(
        (data) => {

        }
      )

    }

  }

  disapprove(cardNumber: number) {
    if (confirm("Press ok to confirm your decision as approve")) {
      this.bankerService.approveOrDisapproveCards(cardNumber, 'Disapprove').subscribe(
        (data) => {

        }
      )

    }

  }

}
