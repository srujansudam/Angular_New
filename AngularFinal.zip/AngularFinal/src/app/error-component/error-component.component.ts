import { Component, OnInit } from '@angular/core';
import { CreditCardService } from '../service/creditcard.service';

@Component({
  selector: 'app-error-component',
  templateUrl: './error-component.component.html',
  styleUrls: ['./error-component.component.css']
})
export class ErrorComponentComponent implements OnInit {

  message :string;
  constructor(private creditsrv : CreditCardService) { }

  ngOnInit() {
    this.message= this.creditsrv.errorMessage;
  }

}
