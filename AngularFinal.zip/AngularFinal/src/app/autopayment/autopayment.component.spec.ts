import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutopaymentComponent } from './autopayment.component';

describe('AutopaymentComponent', () => {
  let component: AutopaymentComponent;
  let fixture: ComponentFixture<AutopaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutopaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutopaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
