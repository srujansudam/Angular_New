import { Component, OnInit } from '@angular/core';
import { AutoPayment } from '../model/autopayment';
import { Account_ServiceProviders } from '../model/account_serviceProviders';
import { AutoPaymentService } from '../service/auto-payment.service';




@Component({
  selector: 'app-autopayment',
  templateUrl: './autopayment.component.html',
  styleUrls: ['./autopayment.component.css']
})
export class AutopaymentComponent implements OnInit {

  newAutopayment: AutoPayment;
  autopayments: AutoPayment[];
  dateOfStart: string;
  dateOfEnd: string;
  errorMessage: any;
  accountSP: Account_ServiceProviders;
  accountNumber: number;


  constructor(private autopaymentService: AutoPaymentService) {
    this.accountNumber = null;
    this.autopayments = [];
    this.newAutopayment = new AutoPayment();
    this.dateOfStart = (new Date).toISOString().substr(0, 10);
    this.dateOfEnd = (new Date).toISOString().substr(0, 10);
    this.accountSP= new Account_ServiceProviders();
  }

  ngOnInit() {
    this.load();
  }

  load() {
   
    this.autopaymentService.showAccounts().subscribe(
      (data)=>{
        this.accountSP=data;
      }
    );

    this.autopaymentService.viewAutopayments().subscribe(
      (data) => {
        this.autopayments = data;
      }
    );
  }

  edit(a: AutoPayment) {
    a.isEditing = true;
  }

  cancelEdit(a: AutoPayment) {
    a.isEditing = false;
  }
  delete(a: AutoPayment) {
    if (confirm("you sure?? think again before deleting!")) {
      this.autopaymentService.deleteAutopayment(a).subscribe(
        () => {
          this.load();
        }
      );
    }
  }

  

  addAutopayment() {
    console.log(this.accountNumber);
    console.log(this.newAutopayment);
    this.autopaymentService.accNumber = this.accountNumber;
    this.newAutopayment.dateOfStart = new Date(this.dateOfStart).toISOString().substr(0,10);
    this.newAutopayment.dateOfEnd = new Date(this.dateOfEnd).toISOString().substr(0,10);
    this.autopaymentService.addAutopayment(this.newAutopayment
    ).subscribe(
      (data) => {
        this.newAutopayment = new AutoPayment();
        this.load();
      },
      (error) => {
        this.errorMessage = error;
        alert(this.errorMessage);
        // this.router.navigate(['/error']);
      }
    );
  }


  update(a: AutoPayment) {
    
      this.autopaymentService.modifyAutopayment(a).subscribe(
        (data) => {
          this.load();
        },
        (error) => {
          this.errorMessage = error;
          alert(this.errorMessage);
        
        }
      );
    }
    
}