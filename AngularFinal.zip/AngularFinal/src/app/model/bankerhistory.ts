export class bankerHistory{

public requestId:number;
public cardNumber:number;	
public accNumber:number;
public decision:string;
public remarks:string;
public bankerId:number;
public timeStamp:Date;
}