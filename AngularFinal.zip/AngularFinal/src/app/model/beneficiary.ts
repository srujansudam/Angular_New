export class Beneficiary{
    public accountNumber:number;
    public  accountName:string;
	public ifscCode:string ;
	public bankName:string ;
	public type:string;
	public status:string;
	public adminRemarks:String ;
	public timestamp:Date;
	public bankId:number;
	public isEditing: boolean = false;

}