import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, BehaviorSubject } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Message } from '../model/Message';
import { Banker } from '../model/banker';
import { Customer } from '../model/customer';
import { Login } from '../model/login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  checkRole:Login;
  baseUrl: string;
  baseUrl1:string;
  customer: Customer;
  banker:Banker;
  private currentUserSubject: BehaviorSubject<Login>;
  public currentUser: Observable<Login>;

  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<Login>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
    this.baseUrl = `${environment.baseMwUrl}/login`;
    this.baseUrl1 = `${environment.baseMwUrl}/banklogin`;
  }

  public get currentUserValue(): Login {
    return this.currentUserSubject.value;
}

  login(userId: string): Observable<Message> {
    return this.http.get<Message>(`${this.baseUrl}/${userId}`)
    .pipe(map(user => {
        // login successful if there's a jwt token in the response
        if (user) {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            this.checkRole.role = "CUSTOMER";
            this.checkRole.userId = user.customer.userId;
            localStorage.setItem('currentUser', JSON.stringify(this.checkRole));
            this.currentUserSubject.next(this.checkRole);
        }

        return user;
    }));
  }

  bankerlogin(userId: string): Observable<Message> {
    return this.http.get<Message>(`${this.baseUrl1}/${userId}`)
    .pipe(map(user => {
        // login successful if there's a jwt token in the response
        if (user) {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            this.checkRole.role = "BANKER";
            this.checkRole.userId = user.banker.userId;
            localStorage.setItem('currentUser', JSON.stringify(this.checkRole));
            this.currentUserSubject.next(this.checkRole);
        }
        return user;
    }));
  }
    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
    }
}




