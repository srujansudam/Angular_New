import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { bankerHistory } from '../model/bankerhistory';
import { Banker } from '../model/banker';
import { Beneficiary } from '../model/beneficiary';
import { CreditCard } from '../model/creditcard';
import { LoginService } from './login.service';

@Injectable({
  providedIn: 'root'
})
export class BankerService {
  baseUrl: string;
  baseUrl1:string;
  
  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/bankAdminBen`;
    this.baseUrl1 = `${environment.baseMwUrl}/bankAdminCard`;
  }

  benRequests(): Observable<Beneficiary[]> {
    return this.http.get<Beneficiary[]>(`${this.baseUrl}`);
  }

  benRequestsForMe(bankerId : number): Observable<Beneficiary[]> {
    return this.http.get<Beneficiary[]>(`${this.baseUrl}/${bankerId}`);
  }

  approveOrDisapproveBeneficiaries(accountNumber: number, decision:string): Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/${accountNumber}/${decision}` );
  }
  cardRequests(): Observable<CreditCard[]> {
    return this.http.get<CreditCard[]>(`${this.baseUrl1}`);
  }

  cardRequestsForMe(bankerId : number): Observable<CreditCard[]> {
    return this.http.get<CreditCard[]>(`${this.baseUrl1}/${bankerId}`);
  }

  approveOrDisapproveCards(cardNumber: number, decision:string): Observable<any>{
    return this.http.get<any>(`${this.baseUrl1}/${cardNumber}/${decision}` );
  }
}