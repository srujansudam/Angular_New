import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banker-welcome',
  templateUrl: './banker-welcome.component.html',
  styleUrls: ['./banker-welcome.component.css']
})
export class BankerWelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
